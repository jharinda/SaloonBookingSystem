import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { Button } from 'primeng/button';
import { Divider } from 'primeng/divider';
import { ProgressSpinner } from 'primeng/progressspinner';
import { Tooltip } from 'primeng/tooltip';
import { MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

import { Booking } from '@org/models';
import { BookingService } from '../services/booking.service';
import { CalendarService } from '../services/calendar.service';
import { PushNotificationDialogComponent } from './push-notification-dialog.component';

@Component({
  selector: 'lib-booking-success',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    DatePipe,
    DecimalPipe,
    Button,
    Divider,
    ProgressSpinner,
    Tooltip,
  ],
  template: `
    <div class="success-container">

      <!-- Header -->
      <div class="success-banner">
        <div class="success-icon-wrapper">
          <i class="pi pi-check-circle success-icon"></i>
        </div>
        <h1 class="success-title">Booking Confirmed!</h1>
        <p class="success-subtitle">
          Your appointment has been booked. You'll receive a confirmation shortly.
        </p>
      </div>

      <!-- Loading state while fetching booking details -->
      @if (isLoading()) {
        <div class="loading-state">
          <p-progressSpinner strokeWidth="3" animationDuration=".8s" [style]="{ width: '40px', height: '40px' }" />
          <span>Loading booking details…</span>
        </div>
      }

      <!-- Error state -->
      @if (!isLoading() && loadError()) {
        <div class="error-state">
          <i class="pi pi-exclamation-circle" style="color:#ef4444;font-size:1.25rem"></i>
          <span>{{ loadError() }}</span>
        </div>
      }

      <!-- Booking details card -->
      @if (!isLoading() && booking()) {
        <div class="details-card">
          <h2 class="details-heading">Appointment Details</h2>

          <div class="detail-row">
            <i class="pi pi-hashtag detail-icon"></i>
            <div>
              <div class="detail-label">Booking ID</div>
              <div class="detail-value detail-value--mono">{{ booking()!._id }}</div>
            </div>
          </div>

          <p-divider />

          <div class="detail-row">
            <i class="pi pi-shop detail-icon"></i>
            <div>
              <div class="detail-label">Salon</div>
              <div class="detail-value">{{ booking()!.salonName }}</div>
            </div>
          </div>

          <p-divider />

          <div class="detail-row">
            <i class="pi pi-scissors detail-icon"></i>
            <div>
              <div class="detail-label">Service</div>
              <div class="detail-value">{{ booking()!.serviceName }}</div>
            </div>
          </div>

          @if (booking()!.stylistName) {
            <p-divider />
            <div class="detail-row">
              <i class="pi pi-user detail-icon"></i>
              <div>
                <div class="detail-label">Stylist</div>
                <div class="detail-value">{{ booking()!.stylistName }}</div>
              </div>
            </div>
          }

          <p-divider />

          <div class="detail-row">
            <i class="pi pi-calendar detail-icon"></i>
            <div>
              <div class="detail-label">Date</div>
              <div class="detail-value">
                {{ booking()!.appointmentDate | date: 'fullDate' }}
              </div>
            </div>
          </div>

          <p-divider />

          <div class="detail-row">
            <i class="pi pi-clock detail-icon"></i>
            <div>
              <div class="detail-label">Time</div>
              <div class="detail-value">
                {{ booking()!.startTime }} – {{ booking()!.endTime }}
              </div>
            </div>
          </div>

          <p-divider />

          <div class="detail-row">
            <i class="pi pi-money-bill detail-icon"></i>
            <div>
              <div class="detail-label">Total</div>
              <div class="detail-value detail-value--price">
                LKR {{ booking()!.totalPrice | number }}
              </div>
            </div>
          </div>

          <div class="status-chip" [class]="'status-chip--' + booking()!.status.toLowerCase()">
            {{ booking()!.status }}
          </div>
        </div>

        <!-- Calendar actions -->
        <div class="calendar-section">
          <h3 class="calendar-heading">
            <i class="pi pi-calendar"></i>
            Add to your calendar
          </h3>

          <div class="calendar-buttons">
            <p-button
              label="Add to Google Calendar"
              icon="pi pi-calendar-plus"
              [loading]="isCalendarLoading()"
              (onClick)="addToGoogleCalendar()"
              pTooltip="Syncs with your Google Calendar account"
              tooltipPosition="top"
            />

            <p-button
              label="Download .ics File"
              icon="pi pi-download"
              [outlined]="true"
              [loading]="isIcsLoading()"
              (onClick)="downloadIcs()"
              pTooltip="Download an .ics file for Apple Calendar, Outlook, etc."
              tooltipPosition="top"
            />
          </div>
        </div>

        <!-- Navigation -->
        <div class="nav-actions">
          <p-button
            label="Find Another Salon"
            icon="pi pi-search"
            [outlined]="true"
            (onClick)="goToDiscover()"
          />
          <p-button
            label="My Bookings"
            icon="pi pi-list"
            [text]="true"
            (onClick)="goToBookings()"
          />
        </div>
      }
    </div>
  `,
  styles: [`
    .success-container {
      max-width: 560px;
      margin: 0 auto;
      padding: 32px 24px 64px;
    }

    /* ── Banner ── */
    .success-banner {
      text-align: center;
      padding: 40px 16px 36px;
    }

    .success-icon-wrapper {
      display: inline-flex;
      background: #dcfce7;
      border-radius: 50%;
      padding: 16px;
      margin-bottom: 16px;
    }

    .success-icon {
      font-size: 3rem;
      color: #16a34a;
    }

    .success-title {
      font-size: 1.75rem;
      font-weight: 700;
      margin: 0 0 10px;
      color: #111827;
    }

    .success-subtitle {
      font-size: 0.97rem;
      color: #6b7280;
      max-width: 380px;
      margin: 0 auto;
      line-height: 1.6;
    }

    /* ── Loading / Error ── */
    .loading-state, .error-state {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 40px;
      color: #6b7280;
      font-size: 0.9rem;
    }

    .error-state { color: #ef4444; }

    /* ── Details card ── */
    .details-card {
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      overflow: hidden;
      background: #fff;
      margin-bottom: 28px;
      padding-bottom: 16px;
    }

    .details-heading {
      font-size: 1rem;
      font-weight: 600;
      padding: 18px 18px 12px;
      margin: 0;
      color: #374151;
    }

    .detail-row {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 14px 18px;
    }

    .detail-icon {
      color: var(--p-primary-500, #7c3aed);
      font-size: 1.2rem;
      flex-shrink: 0;
      margin-top: 2px;
    }

    .detail-label {
      font-size: 0.73rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #9ca3af;
      font-weight: 500;
      margin-bottom: 2px;
    }

    .detail-value {
      font-size: 0.93rem;
      font-weight: 500;
      color: #111827;
    }

    .detail-value--mono { font-family: monospace; font-size: 0.82rem; color: #6b7280; }

    .detail-value--price {
      font-weight: 700;
      font-size: 1.1rem;
      color: var(--p-primary-500, #7c3aed);
    }

    .status-chip {
      display: inline-block;
      margin: 8px 18px 0;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .status-chip--pending    { background: #fef9c3; color: #a16207; }
    .status-chip--confirmed  { background: #dcfce7; color: #166534; }
    .status-chip--cancelled  { background: #fee2e2; color: #991b1b; }
    .status-chip--completed  { background: #ede9fe; color: #5b21b6; }

    /* ── Calendar section ── */
    .calendar-section {
      background: #f8f9fa;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 24px;
    }

    .calendar-heading {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.93rem;
      font-weight: 600;
      color: #374151;
      margin: 0 0 16px;
    }

    .calendar-heading .pi {
      font-size: 1.1rem;
      color: var(--p-primary-500, #7c3aed);
    }

    .calendar-buttons {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
    }

    /* ── Nav ── */
    .nav-actions {
      display: flex;
      justify-content: center;
      gap: 12px;
      flex-wrap: wrap;
    }

    @media (max-width: 480px) {
      .success-container { padding: 20px 16px 40px; }
      .calendar-buttons { flex-direction: column; }
    }

    /* ── Dark mode ─────────────────────────────────────────────── */
    :host-context(.dark) {
      .success-title    { color: #f4f4f5; }
      .success-subtitle { color: #a1a1aa; }

      .success-icon-wrapper { background: rgba(22,163,74,.2); }

      .loading-state { color: #a1a1aa; }

      .details-card {
        background: #18181b;
        border-color: #3f3f46;
      }

      .details-heading { color: #d4d4d8; }

      .detail-label { color: #71717a; }

      .detail-value { color: #f4f4f5; }
      .detail-value--mono { color: #a1a1aa; }

      .status-chip--pending   { background: rgba(254,249,195,.12); color: #fde68a; }
      .status-chip--confirmed { background: rgba(220,252,231,.12); color: #86efac; }
      .status-chip--cancelled { background: rgba(254,226,226,.12); color: #fca5a5; }
      .status-chip--completed { background: rgba(237,233,254,.12); color: #c4b5fd; }

      .calendar-section    { background: #27272a; }
      .calendar-heading    { color: #d4d4d8; }
    }
  `],
})
export class BookingSuccessComponent implements OnInit {
  private readonly route           = inject(ActivatedRoute);
  private readonly bookingService  = inject(BookingService);
  private readonly calendarService = inject(CalendarService);
  private readonly msgSvc          = inject(MessageService);
  private readonly router          = inject(Router);
  private readonly dialogService   = inject(DialogService);

  private pushNotifRef: DynamicDialogRef | null = null;

  private get bookingId(): string {
    return this.route.snapshot.paramMap.get('bookingId') ?? '';
  }

  readonly booking           = signal<Booking | null>(null);
  readonly isLoading         = signal(true);
  readonly loadError         = signal<string | null>(null);
  readonly isCalendarLoading = signal(false);
  readonly isIcsLoading      = signal(false);

  ngOnInit(): void {
    this.bookingService.getById(this.bookingId).subscribe({
      next: (b) => {
        this.booking.set(b);
        this.isLoading.set(false);
        this.maybePromptPushNotifications();
      },
      error: () => {
        this.loadError.set('Could not load booking details.');
        this.isLoading.set(false);
      },
    });
  }

  /** Open the push-notification opt-in dialog (once per browser session). */
  private maybePromptPushNotifications(): void {
    if (sessionStorage.getItem('pn_prompted')) return;
    if ('Notification' in window && Notification.permission !== 'default') return;

    sessionStorage.setItem('pn_prompted', '1');
    setTimeout(() => {
      this.pushNotifRef = this.dialogService.open(PushNotificationDialogComponent, {
        header: 'Stay in the loop',
        width: '380px',
        closable: true,
      });
    }, 800);
  }

  addToGoogleCalendar(): void {
    this.isCalendarLoading.set(true);
    this.calendarService.getGoogleAuthUrl().subscribe({
      next: (res) => {
        window.location.href = res.url;
      },
      error: () => {
        this.isCalendarLoading.set(false);
        this.msgSvc.add({ severity: 'error', summary: 'Error', detail: 'Could not connect to Google Calendar. Please try again.', life: 4000 });
      },
    });
  }

  downloadIcs(): void {
    this.isIcsLoading.set(true);
    this.calendarService.downloadIcs(this.bookingId).subscribe({
      next: (blob) => {
        triggerBlobDownload(blob, `snapsalon-booking-${this.bookingId}.ics`);
        this.isIcsLoading.set(false);
      },
      error: () => {
        this.isIcsLoading.set(false);
        this.msgSvc.add({ severity: 'error', summary: 'Error', detail: 'Could not download calendar file. Please try again.', life: 4000 });
      },
    });
  }

  goToDiscover(): void {
    void this.router.navigate(['/discover']);
  }

  goToBookings(): void {
    void this.router.navigate(['/my-bookings']);
  }
}

// ── Utilities ──────────────────────────────────────────────────────────────────

function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
