
/**
 * IMPORTANT: Do not modify this file.
 * This file allows the app to run without bundling in workspace libraries.
 * Must be contained in the ".nx" folder inside the output path.
 */
const Module = require('module');
const path = require('path');
const fs = require('fs');
const originalResolveFilename = Module._resolveFilename;
const distPath = __dirname;
const manifest = [{"module":"@org/shared/socket","exactMatch":"libs/shared/socket/index.js","pattern":"libs/shared/socket/index.ts"},{"module":"@org/models","exactMatch":"libs/shared/models/src/index.js","pattern":"libs/shared/models/src/index.ts"},{"module":"@org/shared-auth","exactMatch":"libs/shared-auth/src/index.js","pattern":"libs/shared-auth/src/index.ts"},{"module":"@org/shared-data-access","exactMatch":"libs/shared-data-access/src/index.js","pattern":"libs/shared-data-access/src/index.ts"},{"module":"@org/subscription-check","exactMatch":"libs/subscription-check/src/index.js","pattern":"libs/subscription-check/src/index.ts"},{"module":"@org/auth","exactMatch":"libs/features/auth/src/index.js","pattern":"libs/features/auth/src/index.ts"},{"module":"@org/booking","exactMatch":"libs/features/booking/src/index.js","pattern":"libs/features/booking/src/index.ts"},{"module":"@org/discover","exactMatch":"libs/features/discover/src/index.js","pattern":"libs/features/discover/src/index.ts"},{"module":"@org/salon-dashboard","exactMatch":"libs/features/salon-dashboard/src/index.js","pattern":"libs/features/salon-dashboard/src/index.ts"},{"module":"@org/reviews","exactMatch":"libs/features/reviews/src/index.js","pattern":"libs/features/reviews/src/index.ts"},{"module":"@org/account","exactMatch":"libs/features/account/src/index.js","pattern":"libs/features/account/src/index.ts"},{"module":"@org/admin","exactMatch":"libs/features/admin/src/index.js","pattern":"libs/features/admin/src/index.ts"},{"module":"@org/chat","exactMatch":"libs/features/chat/src/index.js","pattern":"libs/features/chat/src/index.ts"}];

Module._resolveFilename = function(request, parent) {
  let found;
  for (const entry of manifest) {
    if (request === entry.module && entry.exactMatch) {
      const entry = manifest.find((x) => request === x.module || request.startsWith(x.module + "/"));
      const candidate = path.join(distPath, entry.exactMatch);
      if (isFile(candidate)) {
        found = candidate;
        break;
      }
    } else {
      const re = new RegExp(entry.module.replace(/\*$/, "(?<rest>.*)"));
      const match = request.match(re);

      if (match?.groups) {
        const candidate = path.join(distPath, entry.pattern.replace("*", ""), match.groups.rest);
        if (isFile(candidate)) {
          found = candidate;
        }
      }

    }
  }
  if (found) {
    const modifiedArguments = [found, ...[].slice.call(arguments, 1)];
    return originalResolveFilename.apply(this, modifiedArguments);
  } else {
    return originalResolveFilename.apply(this, arguments);
  }
};

function isFile(s) {
  try {
    require.resolve(s);
    return true;
  } catch (_e) {
    return false;
  }
}

// Call the user-defined main.
module.exports = require('./apps/api/src/main.js');
