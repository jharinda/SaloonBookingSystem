import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-G3PJ5VCB.js";
import "./chunk-UDOPLKIV.js";
import "./chunk-KBXECFJX.js";
import "./chunk-XX3MGTEB.js";
import "./chunk-Y7HR42RN.js";
import "./chunk-TTBEABAR.js";
import "./chunk-FM5LIKEB.js";
import "./chunk-X7R32L3N.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-MARUHEWW.js";
import "./chunk-H2SRQSE4.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
