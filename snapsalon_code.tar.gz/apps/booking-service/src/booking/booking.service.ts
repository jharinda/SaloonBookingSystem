import {
  BadRequestException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { InjectQueue } from '@nestjs/bull';
import { HttpService } from '@nestjs/axios';
import { Cron, CronExpression } from '@nestjs/schedule';
import { firstValueFrom } from 'rxjs';
import { Model, Types } from 'mongoose';
import { Queue } from 'bull';
import Redis from 'ioredis';

import { Booking, BookingDocument, BookingStatus } from './schemas/booking.schema';
import { CreateBookingDto } from './dto/create-booking.dto';
import { BookingListQueryDto } from './dto/booking-query.dto';
import { RescheduleBookingDto } from './dto/reschedule-booking.dto';
import {
  AvailableSlotsResponseDto,
  BookingResponseDto,
  PaginatedBookingsDto,
} from './dto/booking-response.dto';
import { BOOKING_QUEUE, BookingEvent } from './constants/booking-events.constants';

const SLOT_INTERVAL_MINUTES = 30;
const BOOKING_BUFFER_MINUTES = 15;
const CACHE_TTL_SECONDS = 60;

/** Shape of the operatingHours entry returned by salon-service */
interface SalonOperatingHours {
  day: number;    // 0 = Sunday … 6 = Saturday
  open: string;   // "HH:mm"
  close: string;  // "HH:mm"
  closed: boolean;
}

/** Minimal shape of the salon-service GET /api/salons/:id response */
interface SalonResponse {
  operatingHours: SalonOperatingHours[];
  cancellationWindowHours?: number;
  autoConfirmBookings?: boolean;
}

/** Convert "HH:mm" to total minutes since midnight */
function toMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

/** Convert total minutes since midnight back to "HH:mm" */
function toTimeString(minutes: number): string {
  const h = Math.floor(minutes / 60).toString().padStart(2, '0');
  const m = (minutes % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}

/** Add `durationMinutes` to a "HH:mm" string */
function addMinutes(time: string, duration: number): string {
  return toTimeString(toMinutes(time) + duration);
}

@Injectable()
export class BookingService {
  private readonly logger = new Logger(BookingService.name);

  constructor(
    @InjectModel(Booking.name)
    private readonly bookingModel: Model<BookingDocument>,
    @InjectQueue(BOOKING_QUEUE)
    private readonly bookingQueue: Queue,
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
    @Inject('REDIS_CLIENT')
    private readonly redis: Redis,
  ) {}

  // ── Availability ─────────────────────────────────────────────────────────

  async getAvailableSlots(
    salonId: string,
    stylistId: string | null,
    date: string,
    durationMinutes: number,
  ): Promise<AvailableSlotsResponseDto> {
    // ── Step 0: Redis cache ──────────────────────────────────────────────
    const cacheKey = `slots:${salonId}:${date}:${durationMinutes}:${stylistId ?? 'any'}`;
    try {
      const cached = await this.redis.get(cacheKey);
      if (cached) {
        return JSON.parse(cached) as AvailableSlotsResponseDto;
      }
    } catch (err) {
      this.logger.warn(`Redis cache read failed: ${(err as Error).message}`);
    }

    // ── Step 1: Fetch salon operating hours from salon-service ───────────
    const salonServiceUrl = this.configService.get<string>(
      'services.salonUrl',
      'http://salon-service:3001',
    );

    let salon: SalonResponse;
    try {
      const { data } = await firstValueFrom(
        this.httpService.get<SalonResponse>(
          `${salonServiceUrl}/api/salons/${salonId}`,
        ),
      );
      salon = data;
    } catch (err) {
      this.logger.error(
        `Failed to fetch salon ${salonId} from salon-service: ${(err as Error).message}`,
      );
      throw new BadRequestException(
        `Could not retrieve operating hours for salon ${salonId}`,
      );
    }

    // Find the operating hours entry for the given day of week.
    // Use noon UTC to avoid date-boundary issues with timezone offsets.
    const dayOfWeek = new Date(`${date}T12:00:00.000Z`).getUTCDay();
    const hours = salon.operatingHours?.find((h) => h.day === dayOfWeek);

    if (!hours || hours.closed) {
      const result: AvailableSlotsResponseDto = { salonId, date, slots: [] };
      await this.cacheResult(cacheKey, result);
      return result;
    }

    // ── Step 2: Generate all possible 30-minute-interval slots ───────────
    const openMin = toMinutes(hours.open);
    const closeMin = toMinutes(hours.close);
    const allSlots: string[] = [];

    for (
      let slot = openMin;
      slot + durationMinutes <= closeMin;
      slot += SLOT_INTERVAL_MINUTES
    ) {
      allSlots.push(toTimeString(slot));
    }

    // ── Step 3: Query existing bookings ──────────────────────────────────
    const dayStart = new Date(`${date}T00:00:00.000Z`);
    const dayEnd   = new Date(`${date}T23:59:59.999Z`);

    const bookingQuery: Record<string, unknown> = {
      salonId: new Types.ObjectId(salonId),
      appointmentDate: { $gte: dayStart, $lte: dayEnd },
      status: { $nin: [BookingStatus.CANCELLED, BookingStatus.NO_SHOW] },
    };

    if (stylistId) {
      bookingQuery['stylistId'] = new Types.ObjectId(stylistId);
    }

    const existingBookings = await this.bookingModel
      .find(bookingQuery)
      .lean()
      .exec();

    // ── Step 4: Build blocked ranges (endTime + 15 min buffer) ───────────
    const blocked = existingBookings.map((b) => ({
      start: toMinutes(b.startTime),
      end:   toMinutes(b.endTime) + BOOKING_BUFFER_MINUTES,
    }));

    // ── Step 5: Filter slots that overlap any blocked range ───────────────
    const available = allSlots.filter((slot) => {
      const slotStart = toMinutes(slot);
      const slotEnd   = slotStart + durationMinutes;
      return !blocked.some((b) => slotStart < b.end && slotEnd > b.start);
    });

    const result: AvailableSlotsResponseDto = { salonId, date, slots: available };
    await this.cacheResult(cacheKey, result);
    return result;
  }

  private async cacheResult(key: string, value: unknown): Promise<void> {
    try {
      await this.redis.setex(key, CACHE_TTL_SECONDS, JSON.stringify(value));
    } catch (err) {
      this.logger.warn(`Redis cache write failed: ${(err as Error).message}`);
    }
  }

  // ── CRUD ─────────────────────────────────────────────────────────────────

  async createBooking(
    dto: CreateBookingDto,
    clientId: string,
  ): Promise<BookingResponseDto> {
    const totalDuration = dto.services.reduce(
      (acc, s) => acc + s.durationMinutes,
      0,
    );
    const endTime = addMinutes(dto.startTime, totalDuration);
    const totalPrice = dto.services.reduce((acc, s) => acc + s.price, 0);

    // Acquire a distributed lock to prevent double-booking races
    const lockKey = `booking-lock:${dto.salonId}:${dto.appointmentDate}:${dto.startTime}`;
    const lockValue = await this.acquireLock(lockKey, 5, 3, 100);
    if (!lockValue) {
      throw new BadRequestException(
        'Slot is currently being reserved, please try again',
      );
    }

    try {
      // Validate the slot is still free
      const appointmentDate = new Date(`${dto.appointmentDate}T00:00:00.000Z`);
      const clash = await this.bookingModel.findOne({
        salonId: new Types.ObjectId(dto.salonId),
        appointmentDate,
        status: { $nin: [BookingStatus.CANCELLED, BookingStatus.NO_SHOW] },
        $or: [
          {
            // New booking starts during an existing one
            startTime: { $lt: endTime },
            endTime: { $gt: dto.startTime },
          },
        ],
      });

      if (clash) {
        throw new BadRequestException(
          `The time slot ${dto.startTime}–${endTime} is no longer available`,
        );
      }

      const booking = await this.bookingModel.create({
        clientId: new Types.ObjectId(clientId),
        salonId: new Types.ObjectId(dto.salonId),
        salonName: dto.salonName ?? '',
        clientName: await this.fetchClientName(clientId),
        stylistId: dto.stylistId ? new Types.ObjectId(dto.stylistId) : null,
        services: dto.services.map((s) => ({
          ...s,
          serviceId: new Types.ObjectId(s.serviceId),
        })),
        appointmentDate,
        startTime: dto.startTime,
        endTime,
        totalPrice,
        notes: dto.notes ?? null,
        status: BookingStatus.PENDING,
      });

      const response = this.toResponse(booking);
      await this.bookingQueue.add(BookingEvent.CREATED, response);

      // ── Auto-confirm if the salon has enabled it ─────────────────────
      try {
        const salonServiceUrl = this.configService.get<string>(
          'services.salonUrl',
          'http://salon-service:3001',
        );
        const { data: salonData } = await firstValueFrom(
          this.httpService.get<SalonResponse>(
            `${salonServiceUrl}/api/salons/${dto.salonId}`,
          ),
        );
        if (salonData.autoConfirmBookings) {
          return await this.confirmBooking(String(booking._id));
        }
      } catch (err) {
        this.logger.warn(
          `Auto-confirm check failed for salon ${dto.salonId}: ${
            (err as Error).message
          } — booking left as PENDING`,
        );
      }

      return response;
    } finally {
      await this.releaseLock(lockKey, lockValue);
    }
  }

  async findAll(
    query: BookingListQueryDto,
    filter: Record<string, unknown> = {},
  ): Promise<PaginatedBookingsDto> {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const skip = (page - 1) * limit;
    const where: Record<string, unknown> = { ...filter };

    // clientId is stored as ObjectId — convert the string from JWT so the query matches
    if (where['clientId'] && typeof where['clientId'] === 'string') {
      where['clientId'] = new Types.ObjectId(where['clientId'] as string);
    }

    if (query.salonId) where['salonId'] = new Types.ObjectId(query.salonId);
    if (query.status) where['status'] = query.status;
    if (query.date) {
      where['appointmentDate'] = new Date(`${query.date}T00:00:00.000Z`);
    }
    if (query.startDate || query.endDate) {
      const range: Record<string, Date> = {};
      if (query.startDate) range['$gte'] = new Date(`${query.startDate}T00:00:00.000Z`);
      if (query.endDate) range['$lte'] = new Date(`${query.endDate}T23:59:59.999Z`);
      where['appointmentDate'] = range;
    }

    const [data, total] = await Promise.all([
      this.bookingModel.find(where).skip(skip).limit(limit).lean().exec(),
      this.bookingModel.countDocuments(where),
    ]);

    return {
      data: data.map((b) => this.toResponse(b as unknown as BookingDocument)),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findById(id: string): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findById(id).lean().exec();
    if (!booking) {
      throw new NotFoundException(`Booking ${id} not found`);
    }
    return this.toResponse(booking as unknown as BookingDocument);
  }

  async confirmBooking(bookingId: string): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findById(bookingId);
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);

    if (booking.status !== BookingStatus.PENDING) {
      throw new BadRequestException(
        `Only PENDING bookings can be confirmed (current: ${booking.status})`,
      );
    }

    booking.status = BookingStatus.CONFIRMED;
    await booking.save();

    const response = this.toResponse(booking);
    await this.bookingQueue.add(BookingEvent.CONFIRMED, response);
    return response;
  }

  async cancelBooking(
    bookingId: string,
    userId: string,
    userRole: string,
    reason?: string,
  ): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findById(bookingId);
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);

    const cancellable: BookingStatus[] = [
      BookingStatus.PENDING,
      BookingStatus.CONFIRMED,
    ];
    if (!cancellable.includes(booking.status)) {
      throw new BadRequestException(
        `Cannot cancel a booking with status ${booking.status}`,
      );
    }

    // ── Cancellation window check (clients only) ─────────────────────────────
    const isClient = userRole === 'client';
    if (isClient) {
      const salonServiceUrl = this.configService.get<string>(
        'services.salonUrl',
        'http://salon-service:3001',
      );

      let windowHours = 2;
      try {
        const { data } = await firstValueFrom(
          this.httpService.get<SalonResponse>(
            `${salonServiceUrl}/api/salons/${booking.salonId.toString()}`,
          ),
        );
        windowHours = data.cancellationWindowHours ?? 2;
      } catch (err) {
        this.logger.warn(
          `Could not fetch cancellation window for salon ${booking.salonId.toString()}: ${(err as Error).message}. Defaulting to ${windowHours}h.`,
        );
      }

      const appointmentDateStr = booking.appointmentDate
        .toISOString()
        .split('T')[0];
      const appointmentDt = new Date(
        `${appointmentDateStr}T${booking.startTime}:00+05:30`,
      );
      const msUntilAppointment = appointmentDt.getTime() - Date.now();
      const windowMs = windowHours * 60 * 60 * 1000;

      if (msUntilAppointment > 0 && msUntilAppointment < windowMs) {
        throw new BadRequestException(
          `Cancellations must be made at least ${windowHours} hour${windowHours === 1 ? '' : 's'} before the appointment`,
        );
      }
    }

    booking.status = BookingStatus.CANCELLED;
    booking.cancelledBy = userId;
    booking.cancellationReason = reason;
    await booking.save();

    const response = this.toResponse(booking);
    await this.bookingQueue.add(BookingEvent.CANCELLED, { booking: response, reason });
    return response;
  }

  async rescheduleBooking(
    bookingId: string,
    dto: RescheduleBookingDto,
    userId: string,
  ): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findById(bookingId);
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);

    // Only the client who created the booking may reschedule
    if (booking.clientId.toString() !== userId) {
      throw new ForbiddenException('You can only reschedule your own bookings');
    }

    const reschedulable: BookingStatus[] = [
      BookingStatus.PENDING,
      BookingStatus.CONFIRMED,
    ];
    if (!reschedulable.includes(booking.status)) {
      throw new BadRequestException(
        `Cannot reschedule a booking with status ${booking.status}`,
      );
    }

    // Calculate total service duration (same as at creation time)
    const totalDuration = booking.services.reduce(
      (acc, s) => acc + s.durationMinutes,
      0,
    );

    // Verify the new slot is available
    const availability = await this.getAvailableSlots(
      booking.salonId.toString(),
      booking.stylistId ? booking.stylistId.toString() : null,
      dto.appointmentDate,
      totalDuration,
    );

    if (!availability.slots.includes(dto.startTime)) {
      throw new BadRequestException(
        `The slot ${dto.startTime} on ${dto.appointmentDate} is not available`,
      );
    }

    const wasConfirmed = booking.status === BookingStatus.CONFIRMED;
    const newEndTime = addMinutes(dto.startTime, totalDuration);
    const newAppointmentDate = new Date(`${dto.appointmentDate}T00:00:00.000Z`);

    booking.appointmentDate = newAppointmentDate;
    booking.startTime = dto.startTime;
    booking.endTime = newEndTime;
    await booking.save();

    const response = this.toResponse(booking);

    if (wasConfirmed) {
      await this.bookingQueue.add(BookingEvent.RESCHEDULED, response);
    }

    return response;
  }

  /** Internal: store the Google Calendar event ID returned by calendar-service */
  async setGoogleEventId(
    bookingId: string,
    googleEventId: string,
  ): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findByIdAndUpdate(
      bookingId,
      { googleEventId, calendarSyncStatus: 'synced' },
      { new: true },
    );
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);
    return this.toResponse(booking);
  }

  /** Internal: update calendar sync status called by calendar-service */
  async updateCalendarSyncStatus(
    bookingId: string,
    status: 'pending' | 'synced' | 'failed',
  ): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findByIdAndUpdate(
      bookingId,
      { calendarSyncStatus: status },
      { new: true },
    );
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);
    return this.toResponse(booking);
  }

  async completeBooking(bookingId: string): Promise<BookingResponseDto> {
    const booking = await this.bookingModel.findById(bookingId);
    if (!booking) throw new NotFoundException(`Booking ${bookingId} not found`);

    if (booking.status !== BookingStatus.IN_PROGRESS && booking.status !== BookingStatus.CONFIRMED) {
      throw new BadRequestException(
        `Only CONFIRMED or IN_PROGRESS bookings can be completed (current: ${booking.status})`,
      );
    }

    booking.status = BookingStatus.COMPLETED;
    await booking.save();

    const response = this.toResponse(booking);
    await this.bookingQueue.add(BookingEvent.COMPLETED, response);
    return response;
  }

  // ── Scheduled: auto-complete overdue bookings ─────────────────────────────

  /**
   * Runs every minute.
   * Finds CONFIRMED / IN_PROGRESS bookings whose end time has passed and marks
   * them COMPLETED so the client's appointment list stays accurate without
   * needing manual intervention.
   */
  @Cron(CronExpression.EVERY_MINUTE)
  async autoCompleteOverdueBookings(): Promise<void> {
    const now = new Date();

    // Fetch all active bookings up to (but not including) tomorrow's UTC midnight
    // so we definitely catch everything that could have ended by now.
    const tomorrowUtcMidnight = new Date(now);
    tomorrowUtcMidnight.setUTCHours(0, 0, 0, 0);
    tomorrowUtcMidnight.setUTCDate(tomorrowUtcMidnight.getUTCDate() + 1);

    const candidates = await this.bookingModel
      .find({
        status: { $in: [BookingStatus.CONFIRMED, BookingStatus.IN_PROGRESS] },
        appointmentDate: { $lt: tomorrowUtcMidnight },
      })
      .lean()
      .exec();

    // Reconstruct end datetime from the stored UTC-midnight date + "HH:mm" endTime
    // (endTime is stored in local/salon time, so we use local Date constructor)
    const overdue = candidates.filter((b) => {
      const apptDate = new Date(b.appointmentDate);
      const [hStr, mStr = '0'] = b.endTime.split(':');
      const endDt = new Date(
        apptDate.getUTCFullYear(),
        apptDate.getUTCMonth(),
        apptDate.getUTCDate(),
        parseInt(hStr, 10),
        parseInt(mStr, 10),
      );
      return endDt.getTime() < now.getTime();
    });

    if (!overdue.length) return;

    const ids = overdue.map((b) => b._id);
    await this.bookingModel.updateMany(
      { _id: { $in: ids } },
      { $set: { status: BookingStatus.COMPLETED } },
    );
    this.logger.log(`[Scheduler] Auto-completed ${overdue.length} overdue booking(s)`);

    // Fire COMPLETED events for queue consumers (notifications, calendar, etc.)
    for (const b of overdue) {
      const response = this.toResponse(b as unknown as BookingDocument);
      response.status = BookingStatus.COMPLETED;
      await this.bookingQueue.add(BookingEvent.COMPLETED, response).catch(() => {/* non-fatal */});
    }
  }

  // ── Scheduled: auto-cancel expired pending bookings ───────────────────────

  /**
   * Runs every minute.
   * Finds PENDING bookings whose appointment start time has already passed and
   * marks them CANCELLED.  These are bookings the salon never confirmed — the
   * client should see them as cancelled, not pending, and must NOT be able to
   * leave a review for them.
   */
  @Cron(CronExpression.EVERY_MINUTE)
  async autoCancelExpiredPendingBookings(): Promise<void> {
    const now = new Date();

    const tomorrowUtcMidnight = new Date(now);
    tomorrowUtcMidnight.setUTCHours(0, 0, 0, 0);
    tomorrowUtcMidnight.setUTCDate(tomorrowUtcMidnight.getUTCDate() + 1);

    const candidates = await this.bookingModel
      .find({
        status: BookingStatus.PENDING,
        appointmentDate: { $lt: tomorrowUtcMidnight },
      })
      .lean()
      .exec();

    // Use startTime (not endTime) — if the appointment start has passed and it
    // was never confirmed, there is no point waiting for the end time.
    const expired = candidates.filter((b) => {
      const apptDate = new Date(b.appointmentDate);
      const [hStr, mStr = '0'] = b.startTime.split(':');
      const startDt = new Date(
        apptDate.getUTCFullYear(),
        apptDate.getUTCMonth(),
        apptDate.getUTCDate(),
        parseInt(hStr, 10),
        parseInt(mStr, 10),
      );
      return startDt.getTime() < now.getTime();
    });

    if (!expired.length) return;

    const ids = expired.map((b) => b._id);
    await this.bookingModel.updateMany(
      { _id: { $in: ids } },
      { $set: { status: BookingStatus.CANCELLED } },
    );
    this.logger.log(`[Scheduler] Auto-cancelled ${expired.length} expired pending booking(s)`);

    // Fire CANCELLED events so downstream consumers (notifications, etc.) are aware.
    for (const b of expired) {
      const response = this.toResponse(b as unknown as BookingDocument);
      response.status = BookingStatus.CANCELLED;
      await this.bookingQueue.add(BookingEvent.CANCELLED, response).catch(() => {/* non-fatal */});
    }
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  /**
   * Try to acquire a Redis SET NX EX lock.
   * Returns the unique lock value on success, or null if all retries are exhausted.
   */
  private async acquireLock(
    key: string,
    ttlSeconds: number,
    retries: number,
    retryDelayMs: number,
  ): Promise<string | null> {
    const lockValue = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    for (let attempt = 0; attempt < retries; attempt++) {
      const result = await this.redis.set(key, lockValue, 'EX', ttlSeconds, 'NX');
      if (result === 'OK') {
        return lockValue;
      }
      if (attempt < retries - 1) {
        await new Promise<void>((resolve) => setTimeout(resolve, retryDelayMs));
      }
    }
    return null;
  }

  /**
   * Atomically release a Redis lock only if it still holds our value,
   * preventing accidental release of a lock acquired by another process.
   */
  private async releaseLock(key: string, value: string): Promise<void> {
    const luaScript = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
      else
        return 0
      end
    `;
    try {
      await this.redis.eval(luaScript, 1, key, value);
    } catch (err) {
      this.logger.warn(`Failed to release lock ${key}: ${(err as Error).message}`);
    }
  }

  private async fetchClientName(clientId: string): Promise<string> {
    const authUrl = this.configService.get<string>('services.authUrl', 'http://localhost:3003');
    try {
      const { data } = await firstValueFrom(
        this.httpService.get(`${authUrl}/api/auth/users/${clientId}`),
      );
      return (
        data.name ??
        (`${data.firstName ?? ''} ${data.lastName ?? ''}`.trim() || 'Unknown')
      );
    } catch {
      return '';
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private toResponse(booking: any): BookingResponseDto {
    const id = (booking._id ?? booking.id)?.toString();
    const services = (booking.services ?? []).map(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (s: any) => ({
        serviceId: s.serviceId?.toString(),
        name: s.name,
        price: s.price,
        durationMinutes: s.durationMinutes,
      }),
    );
    return {
      id,
      _id: id,
      clientId: booking.clientId?.toString(),
      clientName: booking.clientName ?? '',
      salonId: booking.salonId?.toString(),
      salonName: booking.salonName ?? '',
      serviceName: services[0]?.name ?? '',
      stylistId: booking.stylistId?.toString() ?? undefined,
      services,
      appointmentDate: booking.appointmentDate,
      startTime: booking.startTime,
      endTime: booking.endTime,
      status: booking.status,
      totalPrice: booking.totalPrice,
      notes: booking.notes ?? undefined,
      googleEventId: booking.googleEventId ?? undefined,
      calendarSyncStatus: booking.calendarSyncStatus ?? 'pending',
      cancelledBy: booking.cancelledBy ?? undefined,
      cancellationReason: booking.cancellationReason ?? undefined,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    };
  }
}
